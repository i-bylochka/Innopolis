class Url:
    BASE_URL = "https://berpress.github.io/"
    LENDING_URL = "online-grocery-store"


class LandingConst:
    TEST_EXIST_GOODS = ["apples", "potatoes"]
    TEST_NON_EXIST_GOODS = ["balalaika", "vodka"]
    NO_RESULT_TEXT = "Nothing here, see github"


class CartConst:
    CART_IS_EMPTY = "Cart is Empty"
    CART_BUY = "Pay done!"
